# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/client/BenchmarkLocation.py
# Compiled at: 2011-07-25 13:59:37
import BigWorld

class BenchmarkLocation(BigWorld.UserDataObject):

    def __init__(self):
        BigWorld.UserDataObject.__init__(self)
