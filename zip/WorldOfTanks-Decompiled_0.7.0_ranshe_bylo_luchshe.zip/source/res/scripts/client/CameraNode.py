# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/client/CameraNode.py
# Compiled at: 2009-09-14 15:02:38
import BigWorld

class CameraNode(BigWorld.UserDataObject):

    def __init__(self):
        BigWorld.UserDataObject.__init__(self)
