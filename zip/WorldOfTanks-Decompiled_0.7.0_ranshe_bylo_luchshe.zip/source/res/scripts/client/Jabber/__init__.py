# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/client/Jabber/__init__.py
# Compiled at: 2011-05-27 19:46:27
pass
