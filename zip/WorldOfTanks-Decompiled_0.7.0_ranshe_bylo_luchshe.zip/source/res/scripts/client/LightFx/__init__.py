# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/client/LightFx/__init__.py
# Compiled at: 2011-05-06 14:14:27
pass
