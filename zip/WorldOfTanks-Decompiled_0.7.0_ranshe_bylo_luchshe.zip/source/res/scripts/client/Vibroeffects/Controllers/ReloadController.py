# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/client/Vibroeffects/Controllers/ReloadController.py
# Compiled at: 2011-03-25 20:17:34
from OnceController import OnceController

class ReloadController(OnceController):

    def __init__(self):
        OnceController.__init__(self, 'shot_reload_veff')
