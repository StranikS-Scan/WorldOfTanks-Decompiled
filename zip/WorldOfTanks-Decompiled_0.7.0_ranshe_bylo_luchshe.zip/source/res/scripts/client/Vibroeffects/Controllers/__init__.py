# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/client/Vibroeffects/Controllers/__init__.py
# Compiled at: 2011-03-25 20:17:34
pass
