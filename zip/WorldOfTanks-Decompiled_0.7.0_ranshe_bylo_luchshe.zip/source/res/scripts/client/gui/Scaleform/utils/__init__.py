# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/Scaleform/utils/__init__.py
# Compiled at: 2011-11-01 17:14:30
pass
