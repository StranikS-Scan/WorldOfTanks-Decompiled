# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/client/messenger/filters.py
# Compiled at: 2011-08-24 13:03:19
