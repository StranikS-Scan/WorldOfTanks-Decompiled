# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/common/__init__.py
# Compiled at: 2011-03-23 18:21:51
pass
