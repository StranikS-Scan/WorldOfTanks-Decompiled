# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/common/dossiers/config.py
# Compiled at: 2010-08-27 16:55:56
RECORD_CONFIGS = {'medalKay': (1, 10, 100, 1000),
 'medalCarius': (10, 100, 1000, 10000),
 'medalKnispel': (10000, 100000, 1000000, 10000000),
 'medalPoppel': (20, 200, 2000, 20000),
 'medalAbrams': (10, 100, 1000, 10000),
 'medalLeClerc': (100, 1000, 10000, 100000),
 'medalLavrinenko': (100, 1000, 10000, 100000),
 'medalEkins': (3, 30, 300, 3000),
 'beasthunter': 100,
 'mousebane': 10,
 'titleSniper': 10,
 'invincible': 5,
 'diehard': 20,
 'handOfDeath': 3,
 'armorPiercer': 5,
 'lumberjack': 10000}
