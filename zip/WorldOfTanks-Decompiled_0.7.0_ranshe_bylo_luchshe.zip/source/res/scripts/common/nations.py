# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/common/nations.py
# Compiled at: 2018-11-30 00:05:30
NAMES = ('ussr', 'germany', 'usa', 'china', 'uk')
INDICES = dict(((n, i) for i, n in enumerate(NAMES)))
AVAILABLE_NAMES = ('ussr', 'germany', 'usa', 'china')
NONE_INDEX = 15
