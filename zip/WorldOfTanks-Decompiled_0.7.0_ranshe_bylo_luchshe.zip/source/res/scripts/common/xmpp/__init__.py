# Python bytecode 2.6 (decompiled from Python 2.7)
# Embedded file name: scripts/common/xmpp/__init__.py
# Compiled at: 2011-04-29 17:11:16
pass
