# Embedded file name: scripts/client/gui/goodies/__init__.py
pass
