# Embedded file name: scripts/client/gui/miniclient/personal_quests/__init__.py
import pointcuts as _pointcuts

def configure_pointcuts():
    _pointcuts.OnViewPopulate()
    _pointcuts.PersonalQuestsTabSelect()
