# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/boosters/__init__.py
__author__ = 'i_malashenko'
