# Embedded file name: scripts/client/AuxiliaryFx/Roccat/__init__.py
pass
