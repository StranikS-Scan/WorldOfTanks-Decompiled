# Embedded file name: scripts/client/gui/battle_control/requests/__init__.py
from gui.battle_control.requests.AvatarRequestsController import AvatarRequestsController
__all__ = ['AvatarRequestsController']
