# Embedded file name: scripts/client/gui/clans/__init__.py
pass
