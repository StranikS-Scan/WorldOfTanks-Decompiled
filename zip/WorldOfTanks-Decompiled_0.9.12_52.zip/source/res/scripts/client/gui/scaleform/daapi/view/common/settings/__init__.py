# Embedded file name: scripts/client/gui/Scaleform/daapi/view/common/settings/__init__.py
from gui.Scaleform.daapi.view.common.settings.SettingsWindow import SettingsWindow
__all__ = ['SettingsWindow']
