# Python 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/account_helpers/settings_core/__init__.py
from account_helpers.settings_core.SettingsCore import g_settingsCore
from account_helpers.settings_core import g_settingsCore
