# Python 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/app_loader/loader.py
