# Python 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/battle_results/__init__.py
pass
