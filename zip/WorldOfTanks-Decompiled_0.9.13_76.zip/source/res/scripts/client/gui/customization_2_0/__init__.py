# Python 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/customization_2_0/__init__.py
from controller import g_customizationController
__all__ = ('g_customizationController',)
