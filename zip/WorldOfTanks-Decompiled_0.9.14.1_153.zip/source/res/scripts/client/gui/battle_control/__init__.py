# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/battle_control/__init__.py
from gui.battle_control.BattleSessionProvider import BattleSessionProvider
g_sessionProvider = BattleSessionProvider()
