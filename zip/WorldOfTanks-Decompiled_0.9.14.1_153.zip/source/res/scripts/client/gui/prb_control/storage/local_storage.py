# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/prb_control/storage/local_storage.py
from constants import QUEUE_TYPE

class LocalStorage(object):
    __slots__ = ()

    def init(self):
        pass

    def fini(self):
        pass

    def swap(self):
        pass

    def release(self, *args):
        pass

    def suspend(self):
        pass

    def isModeSelected(self):
        return False

    def clear(self):
        pass
