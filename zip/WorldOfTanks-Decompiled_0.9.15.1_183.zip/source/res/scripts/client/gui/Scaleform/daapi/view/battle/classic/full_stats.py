# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/Scaleform/daapi/view/battle/classic/full_stats.py
from gui.Scaleform.daapi.view.meta.FullStatsMeta import FullStatsMeta

class FullStatsComponent(FullStatsMeta):

    def __init__(self):
        super(FullStatsComponent, self).__init__()
