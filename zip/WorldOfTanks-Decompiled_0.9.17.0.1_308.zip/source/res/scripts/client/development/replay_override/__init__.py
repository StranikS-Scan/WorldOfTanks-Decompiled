# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/development/replay_override/__init__.py
import BattleReplayPatch
replayPatch = BattleReplayPatch.BattleReplayPatch()
replayPatch.patch()
