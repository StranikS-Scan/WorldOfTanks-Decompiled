# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/miniclient/lobby/profile/__init__.py
import pointcuts as _pointcuts

def configure_pointcuts():
    _pointcuts.MakeClanBtnUnavailable()
    _pointcuts.MakeClubProfileButtonUnavailable()
