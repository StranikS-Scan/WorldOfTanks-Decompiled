# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/login/social_networks/__init__.py
from Manager import Manager, SOCIAL_NETWORKS
__all__ = ('Manager', 'SOCIAL_NETWORKS')
