# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/__init__.py
__author__ = 'd_trofimov'
