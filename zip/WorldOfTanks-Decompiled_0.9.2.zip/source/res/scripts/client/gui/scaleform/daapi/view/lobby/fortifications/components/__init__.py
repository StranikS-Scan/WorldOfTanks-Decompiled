# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/fortifications/components/__init__.py
pass
