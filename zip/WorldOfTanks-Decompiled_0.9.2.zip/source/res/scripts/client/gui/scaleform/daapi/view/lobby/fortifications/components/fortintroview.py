# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/fortifications/components/FortIntroView.py
from gui.Scaleform.daapi.view.meta.FortIntroMeta import FortIntroMeta

class FortIntroView(FortIntroMeta):

    def __init__(self):
        super(FortIntroView, self).__init__()

    def _populate(self):
        super(FortIntroView, self)._populate()

    def _dispose(self):
        super(FortIntroView, self)._dispose()
