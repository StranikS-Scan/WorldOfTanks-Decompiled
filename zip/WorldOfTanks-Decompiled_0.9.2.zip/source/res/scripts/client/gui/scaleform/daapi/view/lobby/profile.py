# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/Profile.py
from gui.Scaleform.daapi import LobbySubView

class Profile(LobbySubView):

    def __init__(self):
        LobbySubView.__init__(self)

    def _populate(self):
        LobbySubView._populate(self)

    def _dispose(self):
        LobbySubView._dispose(self)
