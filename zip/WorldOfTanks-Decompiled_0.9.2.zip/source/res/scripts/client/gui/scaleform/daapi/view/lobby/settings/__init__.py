# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/settings/__init__.py
from gui.Scaleform.daapi.view.lobby.settings.SettingsWindow import SettingsWindow
__all__ = ['SettingsWindow']
