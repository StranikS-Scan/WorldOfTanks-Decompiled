# Embedded file name: scripts/client/gui/Scaleform/daapi/view/meta/ChannelWindowMeta.py
from gui.Scaleform.framework.entities.DAAPIModule import DAAPIModule

class ChannelWindowMeta(DAAPIModule):
    pass
