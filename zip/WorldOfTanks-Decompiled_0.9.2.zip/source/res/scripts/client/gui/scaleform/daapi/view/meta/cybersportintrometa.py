# Embedded file name: scripts/client/gui/Scaleform/daapi/view/meta/CyberSportIntroMeta.py
from gui.Scaleform.daapi.view.lobby.rally.BaseRallyIntroView import BaseRallyIntroView

class CyberSportIntroMeta(BaseRallyIntroView):

    def requestVehicleSelection(self):
        self._printOverrideError('requestVehicleSelection')

    def startAutoMatching(self):
        self._printOverrideError('startAutoMatching')

    def showSelectorPopup(self):
        self._printOverrideError('showSelectorPopup')

    def as_setSelectedVehiclesS(self, vehiclesData, infoText, hasReadyVehicles):
        if self._isDAAPIInited():
            return self.flashObject.as_setSelectedVehicles(vehiclesData, infoText, hasReadyVehicles)
