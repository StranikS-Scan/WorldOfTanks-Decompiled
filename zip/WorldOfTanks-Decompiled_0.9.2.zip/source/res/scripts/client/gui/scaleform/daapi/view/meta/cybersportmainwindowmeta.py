# Embedded file name: scripts/client/gui/Scaleform/daapi/view/meta/CyberSportMainWindowMeta.py
from gui.Scaleform.daapi.view.lobby.rally.BaseRallyMainWindow import BaseRallyMainWindow

class CyberSportMainWindowMeta(BaseRallyMainWindow):
    pass
