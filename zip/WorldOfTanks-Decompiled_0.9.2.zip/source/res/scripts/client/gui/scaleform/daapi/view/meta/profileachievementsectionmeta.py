# Embedded file name: scripts/client/gui/Scaleform/daapi/view/meta/ProfileAchievementSectionMeta.py
from gui.Scaleform.framework.entities.DAAPIModule import DAAPIModule

class ProfileAchievementSectionMeta(DAAPIModule):
    pass
