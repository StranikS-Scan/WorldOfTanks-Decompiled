# Embedded file name: scripts/client/gui/Scaleform/daapi/view/meta/ProfileAwardsMeta.py
from gui.Scaleform.framework.entities.DAAPIModule import DAAPIModule

class ProfileAwardsMeta(DAAPIModule):

    def setFilter(self, data):
        self._printOverrideError('setFilter')
