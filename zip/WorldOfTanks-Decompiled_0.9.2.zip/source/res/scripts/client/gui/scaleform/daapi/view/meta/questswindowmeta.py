# Embedded file name: scripts/client/gui/Scaleform/daapi/view/meta/QuestsWindowMeta.py
from gui.Scaleform.framework.entities.DAAPIModule import DAAPIModule

class QuestsWindowMeta(DAAPIModule):
    pass
