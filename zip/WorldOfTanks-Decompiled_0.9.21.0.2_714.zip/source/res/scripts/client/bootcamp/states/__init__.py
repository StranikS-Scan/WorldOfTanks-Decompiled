# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/bootcamp/states/__init__.py


class STATE(object):
    INITIAL = 0
    BATTLE_PREPARING = 1
    IN_BATTLE = 2
    RESULT_SCREEN = 3
    IN_GARAGE = 4
    OUTRO_VIDEO = 5
    FINISHING = 6
