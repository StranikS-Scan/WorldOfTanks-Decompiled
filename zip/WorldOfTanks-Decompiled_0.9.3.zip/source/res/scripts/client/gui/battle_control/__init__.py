# Embedded file name: scripts/client/gui/battle_control/__init__.py
pass
