# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/headerTutorial/__init__.py
__author__ = 'd_buynitsky'
