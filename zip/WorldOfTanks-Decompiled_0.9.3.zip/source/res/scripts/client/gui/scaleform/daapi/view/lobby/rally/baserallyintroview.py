# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/rally/BaseRallyIntroView.py
from gui.Scaleform.daapi.view.meta.BaseRallyIntroViewMeta import BaseRallyIntroViewMeta
__author__ = 'd_dichkovsky'

class BaseRallyIntroView(BaseRallyIntroViewMeta):

    def __init__(self):
        super(BaseRallyIntroView, self).__init__()
