# Embedded file name: scripts/client/gui/Scaleform/daapi/view/meta/CyberSportMainWindowMeta.py
from gui.Scaleform.daapi.view.lobby.rally.RallyMainWindowWithSearch import RallyMainWindowWithSearch

class CyberSportMainWindowMeta(RallyMainWindowWithSearch):
    pass
