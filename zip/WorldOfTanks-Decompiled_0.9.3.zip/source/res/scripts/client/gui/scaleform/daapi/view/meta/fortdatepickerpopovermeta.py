# Embedded file name: scripts/client/gui/Scaleform/daapi/view/meta/FortDatePickerPopoverMeta.py
from gui.Scaleform.framework.entities.DAAPIModule import DAAPIModule

class FortDatePickerPopoverMeta(DAAPIModule):
    pass
