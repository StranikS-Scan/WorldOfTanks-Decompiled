# Embedded file name: scripts/client/gui/Scaleform/daapi/view/meta/BasePrebattleMainWindowMeta.py
from gui.Scaleform.framework.entities.DAAPIModule import DAAPIModule

class BasePrebattleMainWindowMeta(DAAPIModule):
    pass
