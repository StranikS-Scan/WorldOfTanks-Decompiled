# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/historicalBattles/__init__.py
__all___ = ('HistoricalBattlesListWindow',)
