# Embedded file name: scripts/client/gui/Scaleform/daapi/view/meta/BaseRallyIntroViewMeta.py
from gui.Scaleform.daapi.view.lobby.rally.BaseRallyView import BaseRallyView

class BaseRallyIntroViewMeta(BaseRallyView):
    pass
