# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/rally/RallyMainWindowWithSearch.py
from gui.Scaleform.daapi.view.meta.RallyMainWindowWithSearchMeta import RallyMainWindowWithSearchMeta

class RallyMainWindowWithSearch(RallyMainWindowWithSearchMeta):

    def __init__(self):
        super(RallyMainWindowWithSearch, self).__init__()
