# Embedded file name: scripts/client/avatar_helpers/__init__.py
import BigWorld
