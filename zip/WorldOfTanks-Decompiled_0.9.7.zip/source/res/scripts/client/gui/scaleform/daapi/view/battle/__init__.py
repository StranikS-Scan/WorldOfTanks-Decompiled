# Embedded file name: scripts/client/gui/Scaleform/daapi/view/battle/__init__.py
AMMO_ICON_PATH = '../maps/icons/ammopanel/ammo/%s'
NO_AMMO_ICON_PATH = '../maps/icons/ammopanel/ammo/NO_%s'
COMMAND_AMMO_CHOICE_MASK = 'CMD_AMMO_CHOICE_{0:d}'
