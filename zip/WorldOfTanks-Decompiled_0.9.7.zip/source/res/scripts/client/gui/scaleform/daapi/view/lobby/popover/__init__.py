# Embedded file name: scripts/client/gui/Scaleform/daapi/view/lobby/popover/__init__.py
pass
