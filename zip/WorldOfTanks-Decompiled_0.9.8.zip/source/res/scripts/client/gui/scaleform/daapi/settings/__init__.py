# Embedded file name: scripts/client/gui/Scaleform/daapi/settings/__init__.py
__author__ = 'd_dichkovsky'
