# Embedded file name: scripts/client/gui/awards/__init__.py
pass
