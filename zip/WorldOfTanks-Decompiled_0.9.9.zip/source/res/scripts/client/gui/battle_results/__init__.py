# Embedded file name: scripts/client/gui/battle_results/__init__.py
pass
