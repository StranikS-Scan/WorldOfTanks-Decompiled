# Embedded file name: scripts/client/gui/battle_results/results/regular.py
from gui.battle_results import abstract

class RegularResults(abstract.BattleResults):
    pass
