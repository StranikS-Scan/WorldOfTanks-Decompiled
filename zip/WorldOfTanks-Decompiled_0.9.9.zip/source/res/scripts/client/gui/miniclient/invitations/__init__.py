# Embedded file name: scripts/client/gui/miniclient/invitations/__init__.py
import pointcuts as _pointcuts

def configure_pointcuts():
    _pointcuts.DisableAcceptButton()
    _pointcuts.InvitationText()
