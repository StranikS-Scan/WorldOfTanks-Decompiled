# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/gui/battle_results/templates/cybersport.py
from gui.battle_results.components import base
CYBER_SPORT_BLOCK = base.StatsBlock(base.DictMeta({'teams': {}}), 'cyberSport')
