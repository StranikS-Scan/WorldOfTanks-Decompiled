# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/ArenaMinesComponent.py
import BigWorld

class ArenaMinesComponent(BigWorld.DynamicScriptComponent):
    pass
