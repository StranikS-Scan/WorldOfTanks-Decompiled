# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/BenchmarkLocation.py
import BigWorld

class BenchmarkLocation(BigWorld.UserDataObject):

    def __init__(self):
        BigWorld.UserDataObject.__init__(self)
