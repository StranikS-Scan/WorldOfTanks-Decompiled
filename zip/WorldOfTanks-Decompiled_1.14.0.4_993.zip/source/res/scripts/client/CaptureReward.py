# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/CaptureReward.py
from script_component.DynamicScriptComponent import DynamicScriptComponent

class CaptureReward(DynamicScriptComponent):
    pass
