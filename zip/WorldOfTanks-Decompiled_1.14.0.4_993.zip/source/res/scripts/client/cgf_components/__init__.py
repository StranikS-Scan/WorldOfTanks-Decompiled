# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/cgf_components/__init__.py


class IsSelected(object):

    def __init__(self):
        pass


class IsHighlighted(object):

    def __init__(self):
        pass


class HunterTag(object):

    def __init__(self):
        pass


class BossTag(object):

    def __init__(self):
        pass


class BotTag(object):

    def __init__(self):
        pass


class PlayerVehicleTag(object):

    def __init__(self):
        pass
