# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: halloween/scripts/client/HWBossFightTracker.py
import BigWorld
import logging
_logger = logging.getLogger(__name__)

class HWBossFightTracker(BigWorld.DynamicScriptComponent):
    pass
