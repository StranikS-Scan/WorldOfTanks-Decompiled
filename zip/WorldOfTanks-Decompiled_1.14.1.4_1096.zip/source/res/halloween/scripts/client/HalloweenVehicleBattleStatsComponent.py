# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: halloween/scripts/client/HalloweenVehicleBattleStatsComponent.py
import BigWorld

class HalloweenVehicleBattleStatsComponent(BigWorld.DynamicScriptComponent):

    def onEnterWorld(self, *args):
        pass

    def onLeaveWorld(self, *args):
        pass
