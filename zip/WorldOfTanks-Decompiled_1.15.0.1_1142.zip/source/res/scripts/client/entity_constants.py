# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/entity_constants.py


class HighlightColors(object):
    YELLOW = 0
    RED = 1
    GREEN = 2
    BLUE = 3
