# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: event_platform/scripts/client/event_platform/gui/impl/__init__.py
from event_platform.gui.impl.event_hangar import EventHangar
__all__ = ('EventHangar',)
