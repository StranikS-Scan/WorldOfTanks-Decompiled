# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/battleground/iself_assembler.py


class ISelfAssembler(object):

    def assembleOnLoad(self):
        pass
