# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/AvatarLivesComponent.py
from script_component.DynamicScriptComponent import DynamicScriptComponent

class AvatarLivesComponent(DynamicScriptComponent):
    pass
