# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: fun_random/scripts/client/fun_random/gui/shared/tooltips/__init__.py
from shared_utils import CONST_CONTAINER

class TooltipType(CONST_CONTAINER):
    FUN_RANDOM = 'funRandom'
