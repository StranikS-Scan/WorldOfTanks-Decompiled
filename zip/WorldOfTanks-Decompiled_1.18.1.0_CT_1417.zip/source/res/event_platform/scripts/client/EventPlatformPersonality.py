# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: event_platform/scripts/client/EventPlatformPersonality.py
from debug_utils import LOG_DEBUG

def preInit():
    pass


def init():
    LOG_DEBUG('init', __name__)


def start():
    pass


def fini():
    pass
