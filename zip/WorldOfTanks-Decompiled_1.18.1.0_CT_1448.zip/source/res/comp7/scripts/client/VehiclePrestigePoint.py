# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: comp7/scripts/client/VehiclePrestigePoint.py
import BigWorld

class VehiclePrestigePoint(BigWorld.DynamicScriptComponent):

    def __init__(self):
        BigWorld.DynamicScriptComponent.__init__(self)

    def onEnterWorld(self, *args):
        pass

    def onLeaveWorld(self, *args):
        pass
