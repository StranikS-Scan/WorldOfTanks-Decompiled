# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: fun_random/scripts/client/fun_random/gui/prb_control/prb_config.py
from gui.prb_control import settings
ATTR_NAME = 'FUN_RANDOM'

class PrebattleActionName(settings.PREBATTLE_ACTION_NAME):
    FUN_RANDOM = 'fun_random'


class FunctionalFlag(settings.FUNCTIONAL_FLAG):
    FUN_RANDOM = 268435456


class SelectorBattleTypes(settings.SELECTOR_BATTLE_TYPES):
    FUN_RANDOM = 'funRandom'
