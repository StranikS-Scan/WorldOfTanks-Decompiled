# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: halloween/scripts/client/halloween/gui/Scaleform/daapi/view/lobby/hangar/carousel/__init__.py
from halloween.gui.Scaleform.daapi.view.lobby.hangar.carousel.tank_carousel import HW22TankCarousel
__all__ = ('HW22TankCarousel',)
