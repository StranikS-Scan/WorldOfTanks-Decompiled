# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: comp7/scripts/client/VehicleComp7Component.py
from script_component.ScriptComponent import ScriptComponent

class VehicleComp7Component(ScriptComponent):
    pass
