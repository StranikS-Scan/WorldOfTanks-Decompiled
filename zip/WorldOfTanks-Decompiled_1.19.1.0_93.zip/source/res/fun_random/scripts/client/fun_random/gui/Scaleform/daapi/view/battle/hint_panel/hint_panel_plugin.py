# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: fun_random/scripts/client/fun_random/gui/Scaleform/daapi/view/battle/hint_panel/hint_panel_plugin.py
from gui.Scaleform.daapi.view.battle.shared.hint_panel import hint_panel_plugin

class HelpHintContext(hint_panel_plugin.HelpHintContext):
    FUN_RANDOM = 'funRandom'
