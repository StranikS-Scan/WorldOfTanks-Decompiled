# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: abc_tester/scripts/client/AccountAbcTesterComponent.py
from BaseAccountExtensionComponent import BaseAccountExtensionComponent

class AccountAbcTesterComponent(BaseAccountExtensionComponent):
    pass
