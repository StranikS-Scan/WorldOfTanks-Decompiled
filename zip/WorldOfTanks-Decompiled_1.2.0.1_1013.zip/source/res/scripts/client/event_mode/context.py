# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/event_mode/context.py
from bootcamp.BootcampContext import Chapter as BootcampChapter

class Chapter(BootcampChapter):
    _FILE_PATH = 'scripts/item_defs/event/entities.xml'
