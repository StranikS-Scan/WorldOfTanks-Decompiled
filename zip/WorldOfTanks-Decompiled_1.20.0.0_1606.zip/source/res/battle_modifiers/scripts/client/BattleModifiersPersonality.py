# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_modifiers/scripts/client/BattleModifiersPersonality.py
import BattleModifiersPersonalityCommon

def preInit():
    BattleModifiersPersonalityCommon.preInit()


def init():
    pass


def start():
    pass


def fini():
    pass
