# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: fun_random/scripts/client/fun_random/gui/ingame_help/__init__.py
from gui.ingame_help import detailed_help_pages

class HelpPagePriority(detailed_help_pages.HelpPagePriority):
    FUN_RANDOM = 100
