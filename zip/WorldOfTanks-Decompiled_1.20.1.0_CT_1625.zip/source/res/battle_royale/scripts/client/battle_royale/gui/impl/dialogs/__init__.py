# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/battle_royale/gui/impl/dialogs/__init__.py
from enum import Enum

class CurrencyTypeExtended(Enum):
    CREDITS = 'credits'
    GOLD = 'gold'
    CRYSTAL = 'crystal'
    XP = 'xp'
    FREEXP = 'freeXP'
    BR_COIN = 'brcoin'
