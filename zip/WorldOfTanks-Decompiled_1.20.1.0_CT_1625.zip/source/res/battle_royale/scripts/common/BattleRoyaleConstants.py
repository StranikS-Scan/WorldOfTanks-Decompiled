# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/common/BattleRoyaleConstants.py
CMD_BATTLE_ROYALE_TEST_DRIVE = 21001
CMD_BATTLE_ROYALE_RENT = 21002
CMD_BATTLE_ROYALE_OPERATE_BRCOIN = 21003
CMD_BATTLE_ROYALE_RENT_ALL = 21004
