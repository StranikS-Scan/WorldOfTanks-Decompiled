# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/battle_royale/gui/prb_control/entities/regular/squad/action_handler.py
from gui.prb_control.entities.base.squad.actions_handler import SquadActionsHandler

class BattleRoyaleSquadActionsHandler(SquadActionsHandler):
    pass
