# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: abc_tester/scripts/client/AbcTesterPersonality.py
from debug_utils import LOG_DEBUG
LOBBY_EXT_PACKAGES = ()
BATTLE_EXT_PACKAGES = ()

def preInit():
    LOG_DEBUG('preInit personality:', __name__)


def init():
    pass


def start():
    pass


def fini():
    pass
