# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: fun_random/scripts/client/fun_random/gui/doc_loaders/__init__.py
from collections import namedtuple
VehicleParametersConfig = namedtuple('VehicleParametersConfig', ('parameters', 'vehicles'))
VehicleParameters = namedtuple('VehicleParameters', ('strengths', 'weaknesses', 'description'))
