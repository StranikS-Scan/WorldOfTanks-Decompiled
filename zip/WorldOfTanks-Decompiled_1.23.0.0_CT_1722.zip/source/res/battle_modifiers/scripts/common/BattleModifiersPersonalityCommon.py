# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_modifiers/scripts/common/BattleModifiersPersonalityCommon.py
import extension_rules
import battle_modifiers_ext

def preInit():
    extension_rules.init()
    battle_modifiers_ext.init()
