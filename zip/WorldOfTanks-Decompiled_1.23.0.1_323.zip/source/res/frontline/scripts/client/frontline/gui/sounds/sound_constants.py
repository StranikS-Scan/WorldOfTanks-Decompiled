# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: frontline/scripts/client/frontline/gui/sounds/sound_constants.py


class FL_BATTLE_UPGRADE_PANEL_SOUND_EVENTS(object):
    UPGRADE_PANEL_SHOW = 'eb_reserves_widget_on'
    UPGRADE_PANEL_HIDE = 'eb_reserves_widget_off'
    ON_SELECT = 'eb_reserves_widget_click'
    ON_SELECT_STACK_RESERVE = 'eb_reserves_stack'
