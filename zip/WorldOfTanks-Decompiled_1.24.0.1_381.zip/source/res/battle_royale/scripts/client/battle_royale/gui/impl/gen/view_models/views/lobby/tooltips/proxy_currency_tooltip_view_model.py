# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/battle_royale/gui/impl/gen/view_models/views/lobby/tooltips/proxy_currency_tooltip_view_model.py
from frameworks.wulf import ViewModel

class ProxyCurrencyTooltipViewModel(ViewModel):
    __slots__ = ()

    def __init__(self, properties=0, commands=0):
        super(ProxyCurrencyTooltipViewModel, self).__init__(properties=properties, commands=commands)

    def _initialize(self):
        super(ProxyCurrencyTooltipViewModel, self)._initialize()
