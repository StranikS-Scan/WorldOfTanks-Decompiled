# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/battle_royale/gui/impl/gen/view_models/views/lobby/tooltips/shop_tooltip_view_model.py
from frameworks.wulf import ViewModel

class ShopTooltipViewModel(ViewModel):
    __slots__ = ()

    def __init__(self, properties=0, commands=0):
        super(ShopTooltipViewModel, self).__init__(properties=properties, commands=commands)

    def _initialize(self):
        super(ShopTooltipViewModel, self)._initialize()
