# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: event_lootboxes/scripts/client/event_lootboxes/gui/impl/gen/view_models/views/lobby/event_lootboxes/open_box_error_view_model.py
from frameworks.wulf import ViewModel

class OpenBoxErrorViewModel(ViewModel):
    __slots__ = ()

    def __init__(self, properties=0, commands=0):
        super(OpenBoxErrorViewModel, self).__init__(properties=properties, commands=commands)

    def _initialize(self):
        super(OpenBoxErrorViewModel, self)._initialize()
