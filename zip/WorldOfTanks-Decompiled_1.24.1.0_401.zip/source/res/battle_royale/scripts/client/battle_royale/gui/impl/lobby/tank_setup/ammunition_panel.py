# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/battle_royale/gui/impl/lobby/tank_setup/ammunition_panel.py
from gui.impl.lobby.tank_setup.ammunition_panel.hangar_view import HangarAmmunitionPanelView

class BattleRoyaleAmmunitionPanelView(HangarAmmunitionPanelView):
    pass
