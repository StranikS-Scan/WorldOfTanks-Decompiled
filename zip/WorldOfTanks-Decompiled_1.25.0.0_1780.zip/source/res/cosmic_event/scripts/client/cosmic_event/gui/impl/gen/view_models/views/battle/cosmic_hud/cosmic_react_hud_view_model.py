# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: cosmic_event/scripts/client/cosmic_event/gui/impl/gen/view_models/views/battle/cosmic_hud/cosmic_react_hud_view_model.py
from frameworks.wulf import ViewModel

class CosmicReactHudViewModel(ViewModel):
    __slots__ = ()

    def __init__(self, properties=0, commands=0):
        super(CosmicReactHudViewModel, self).__init__(properties=properties, commands=commands)

    def _initialize(self):
        super(CosmicReactHudViewModel, self)._initialize()
