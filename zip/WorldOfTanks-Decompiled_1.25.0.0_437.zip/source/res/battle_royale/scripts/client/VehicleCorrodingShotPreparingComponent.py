# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/VehicleCorrodingShotPreparingComponent.py
import BigWorld
from battle_royale.gui.constants import BattleRoyaleEquipments

class VehicleCorrodingShotPreparingComponent(BigWorld.DynamicScriptComponent):
    EQUIPMENT_NAME = BattleRoyaleEquipments.CORRODING_SHOT
