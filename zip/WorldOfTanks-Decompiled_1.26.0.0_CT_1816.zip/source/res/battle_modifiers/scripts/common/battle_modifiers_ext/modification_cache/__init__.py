# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_modifiers/scripts/common/battle_modifiers_ext/modification_cache/__init__.py
import vehicle_modifications
import constants_modifications

def init():
    vehicle_modifications.init()
    constants_modifications.init()
