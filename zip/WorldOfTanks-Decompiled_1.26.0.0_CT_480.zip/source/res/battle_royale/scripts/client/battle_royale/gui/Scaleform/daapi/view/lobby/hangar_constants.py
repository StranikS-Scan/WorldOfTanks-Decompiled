# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/battle_royale/gui/Scaleform/daapi/view/lobby/hangar_constants.py
from constants_utils import ConstInjector
from gui.Scaleform.daapi.view.lobby.hangar.header_helpers import flag_constants

class QuestFlagTypes(flag_constants.QuestFlagTypes, ConstInjector):
    _const_type = str
    BATTLE_ROYALE = 'battleRoyaleQuests'
