# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/battle_royale/gui/impl/gen/view_models/views/battle/views/leave_battle_view_model.py
from gui.impl.gen.view_models.views.dialogs.dialog_template_view_model import DialogTemplateViewModel

class LeaveBattleViewModel(DialogTemplateViewModel):
    __slots__ = ()

    def __init__(self, properties=6, commands=2):
        super(LeaveBattleViewModel, self).__init__(properties=properties, commands=commands)

    def _initialize(self):
        super(LeaveBattleViewModel, self)._initialize()
