# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: frontline/scripts/client/frontline/gui/frontline_gui_constants.py
from gui.limited_ui.lui_rules_storage import LUI_RULES
_LUI_RULE_ENTRY_POINT = 'EpicBattlesEntryPoint'
_LUI_RULES = [_LUI_RULE_ENTRY_POINT]

def initFLLimitedUIIDs():
    LUI_RULES.inject(_LUI_RULES)
