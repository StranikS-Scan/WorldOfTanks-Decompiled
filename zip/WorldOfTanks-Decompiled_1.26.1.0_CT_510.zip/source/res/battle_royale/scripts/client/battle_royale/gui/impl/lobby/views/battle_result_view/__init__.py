# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/battle_royale/gui/impl/lobby/views/battle_result_view/__init__.py
BATTLE_ROYALE_LOCK_SOURCE_NAME = 'BATTLE_ROYALE_RESULTS_LOGIC'
