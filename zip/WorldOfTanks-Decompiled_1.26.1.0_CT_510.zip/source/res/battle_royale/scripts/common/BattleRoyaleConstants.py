# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/common/BattleRoyaleConstants.py
CMD_BATTLE_ROYALE_OPERATE_BRCOIN = 21003
CMD_BATTLE_ROYALE_SET_RATING = 21005
BATTLE_ROYALE_REPAIR_COST = 10000
