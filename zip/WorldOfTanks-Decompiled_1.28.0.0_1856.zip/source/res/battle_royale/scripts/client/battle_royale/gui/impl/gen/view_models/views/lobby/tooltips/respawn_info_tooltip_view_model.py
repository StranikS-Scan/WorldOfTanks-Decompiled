# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/battle_royale/gui/impl/gen/view_models/views/lobby/tooltips/respawn_info_tooltip_view_model.py
from frameworks.wulf import ViewModel

class RespawnInfoTooltipViewModel(ViewModel):
    __slots__ = ()

    def __init__(self, properties=0, commands=0):
        super(RespawnInfoTooltipViewModel, self).__init__(properties=properties, commands=commands)

    def _initialize(self):
        super(RespawnInfoTooltipViewModel, self)._initialize()
