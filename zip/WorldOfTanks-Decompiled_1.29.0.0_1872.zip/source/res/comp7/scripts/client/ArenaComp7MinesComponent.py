# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: comp7/scripts/client/ArenaComp7MinesComponent.py
import BigWorld

class ArenaComp7MinesComponent(BigWorld.DynamicScriptComponent):
    pass
