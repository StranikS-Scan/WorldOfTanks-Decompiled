# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: armory_yard/scripts/client/armory_yard/gui/impl/gen/view_models/views/lobby/feature/tooltips/entry_point_not_active_tooltip_view_model.py
from frameworks.wulf import ViewModel

class EntryPointNotActiveTooltipViewModel(ViewModel):
    __slots__ = ()

    def __init__(self, properties=0, commands=0):
        super(EntryPointNotActiveTooltipViewModel, self).__init__(properties=properties, commands=commands)

    def _initialize(self):
        super(EntryPointNotActiveTooltipViewModel, self)._initialize()
