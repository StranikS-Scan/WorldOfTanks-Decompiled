# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: armory_yard/scripts/client/armory_yard/gui/impl/gen/view_models/views/lobby/feature/armory_yard_reward_state.py
from frameworks.wulf import ViewModel

class ArmoryYardRewardState(ViewModel):
    __slots__ = ()
    STAGE = 'stage'
    STYLE = 'style'
    SHOP = 'shop'

    def __init__(self, properties=0, commands=0):
        super(ArmoryYardRewardState, self).__init__(properties=properties, commands=commands)

    def _initialize(self):
        super(ArmoryYardRewardState, self)._initialize()
