# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: armory_yard/scripts/client/armory_yard/gui/impl/gen/view_models/views/lobby/feature/tooltips/armory_yard_token_stepper_tooltip_view_model.py
from frameworks.wulf import ViewModel

class ArmoryYardTokenStepperTooltipViewModel(ViewModel):
    __slots__ = ()

    def __init__(self, properties=0, commands=0):
        super(ArmoryYardTokenStepperTooltipViewModel, self).__init__(properties=properties, commands=commands)

    def _initialize(self):
        super(ArmoryYardTokenStepperTooltipViewModel, self)._initialize()
