# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: comp7/scripts/client/Comp7ExtensionPersonality.py
from comp7.gui.Scaleform import registerComp7Scaleform, registerComp7TooltipsBuilders

def preInit():
    registerComp7Scaleform()
    registerComp7TooltipsBuilders()


def init():
    pass


def start():
    pass


def fini():
    pass
