# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: comp7/scripts/common/comp7_account_commands.py
CMD_QUAL_COMPLETE_PRODUCT_DEV = 30001
