# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/ConeVisibility.py
import BigWorld

class ConeVisibility(BigWorld.ScriptComponent):

    def onEnterWorld(self, *args):
        pass

    def onLeaveWorld(self, *args):
        pass
