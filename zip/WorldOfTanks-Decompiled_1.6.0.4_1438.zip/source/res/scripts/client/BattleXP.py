# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/BattleXP.py
import BigWorld

class BattleXP(BigWorld.ScriptComponent):

    def onEnterWorld(self, *args):
        pass

    def onLeaveWorld(self, *args):
        pass
