# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/bootcamp/statistic/__init__.py


class STATISTIC_SETTINGS:
    TEST_MODE = False
    CLIENT_LOG = False
    HOST = 'https://wotuilog.wargaming.net/ui/log/'
    HTTP_METHOD = 'POST'
    REQUEST_TIMEOUT = 30
    REQUEST_HEADERS = {'Content-Type': 'application/json'}
