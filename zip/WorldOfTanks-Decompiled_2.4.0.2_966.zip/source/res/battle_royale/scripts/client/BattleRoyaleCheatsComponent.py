# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/BattleRoyaleCheatsComponent.py
from __future__ import absolute_import
from script_component.DynamicScriptComponent import DynamicScriptComponent

class BattleRoyaleCheatsComponent(DynamicScriptComponent):
    pass
