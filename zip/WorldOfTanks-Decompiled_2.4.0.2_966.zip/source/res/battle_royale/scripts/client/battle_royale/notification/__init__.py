# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_royale/scripts/client/battle_royale/notification/__init__.py
from __future__ import absolute_import
from battle_royale.notification.actions_handlers import ShowBRProgressionActionHandler
from gui.shared.system_factory import registerNotificationsActionsHandlers

def registerClientNotificationHandlers():
    registerNotificationsActionsHandlers((ShowBRProgressionActionHandler,))
