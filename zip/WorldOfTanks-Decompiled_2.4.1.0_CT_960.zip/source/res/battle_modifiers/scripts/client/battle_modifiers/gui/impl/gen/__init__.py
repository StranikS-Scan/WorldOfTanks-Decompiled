# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: battle_modifiers/scripts/client/battle_modifiers/gui/impl/gen/__init__.py
from __future__ import absolute_import
from .resources import R
__all__ = ('R',)
