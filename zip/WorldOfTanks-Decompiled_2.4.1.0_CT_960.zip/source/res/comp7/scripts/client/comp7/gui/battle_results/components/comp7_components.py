# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: comp7/scripts/client/comp7/gui/battle_results/components/comp7_components.py
from __future__ import absolute_import
from comp7.gui.Scaleform.genConsts.TOOLTIPS_CONSTANTS import TOOLTIPS_CONSTANTS as COMP7_TOOLTIPS
from comp7.gui.impl.gen.view_models.views.lobby.enums import SeasonName
from comp7.gui.impl.gen.view_models.views.lobby.qualification_battle import BattleState
from comp7.gui.impl.lobby.comp7_helpers import comp7_shared, comp7_i18n_helpers
from comp7_core.gui.impl.lobby.comp7_core_helpers import comp7_core_model_helpers
from comp7_core.gui.battle_results.components.comp7_core_components import checkIfDeserter
from comp7_ranks_common import EXTRA_RANK_TAG
from fairplay_violation_types import FairplayViolations
from gui.Scaleform.genConsts.COMP7_CONSTS import COMP7_CONSTS
from gui.battle_results.components import base
from gui.battle_results.settings import PLAYER_TEAM_RESULT
from gui.impl import backport
from gui.impl.gen.resources import R
from gui.shared.formatters import text_styles
from helpers import dependency
from skeletons.gui.game_control import IComp7Controller

def isQualificationBattle(avatarResults):
    return avatarResults.get('comp7QualActive', False)


def getFormattedRating(rating):
    return '{:+}'.format(rating) if rating != 0 else str(rating)


class PrestigePointsBlock(base.StatsBlock):
    __slots__ = ('isVisible', 'value', 'label', 'tooltip')

    def __init__(self, meta=None, field='', *path):
        super(PrestigePointsBlock, self).__init__(meta, field, *path)
        self.isVisible = False
        self.value = ''
        self.label = ''
        self.tooltip = ''

    def setRecord(self, result, reusable, tooltip=COMP7_TOOLTIPS.COMP7_BATTLE_RESULTS_RATING_POINTS):
        avatarResults = result.get('avatar', {})
        if not isQualificationBattle(avatarResults):
            self.isVisible = True
            achievedComp7Rating = getFormattedRating(avatarResults.get('comp7RatingDelta', 0))
            self.value = text_styles.grandTitle(achievedComp7Rating)
            self.label = text_styles.creditsSmall(backport.text(R.strings.comp7_ext.battleResult.personal.label()))
            self.tooltip = tooltip


class TournamentRatingPointsBlock(PrestigePointsBlock):

    def setRecord(self, result, reusable):
        super(TournamentRatingPointsBlock, self).setRecord(result, reusable, COMP7_TOOLTIPS.TOURNAMENT_COMP7_BATTLE_RESULTS_RATING_POINTS)


class TrainingRatingPointsBlock(PrestigePointsBlock):

    def setRecord(self, result, reusable):
        self.isVisible = True
        self.value = text_styles.grandTitle('0')
        self.label = text_styles.creditsSmall(backport.text(R.strings.comp7_ext.battleResult.personal.label()))
        self.tooltip = COMP7_TOOLTIPS.TRAINING_COMP7_BATTLE_RESULTS_RATING_POINTS


class IsDeserterFlag(base.StatsItem):

    def _convert(self, value, reusable):
        if checkIfDeserter(reusable, FairplayViolations.COMP7_DESERTER):
            if isQualificationBattle(value.get('avatar', {})):
                return backport.text(R.strings.comp7_ext.battleResult.header.deserterQualification())
            return backport.text(R.strings.comp7_ext.battleResult.header.deserter())
        else:
            return None


class Comp7RankBlock(base.StatsBlock):
    __slots__ = ('linkage', 'title', 'descr', 'icon', 'ratingDiff', 'hasProgressBar', 'progressBegin', 'progressCurrent', 'progressTotal', 'ratingTotal')
    __comp7Controller = dependency.descriptor(IComp7Controller)

    def __init__(self, meta=None, field='', *path):
        super(Comp7RankBlock, self).__init__(meta, field, *path)
        self.linkage = None
        self.title = ''
        self.descr = ''
        self.icon = ''
        self.ratingDiff = ''
        self.hasProgressBar = False
        self.progressBegin = 0
        self.progressCurrent = 0
        self.progressTotal = 0
        self.ratingTotal = ''
        return

    def setRecord(self, result, reusable):
        avatarResults = result.get('avatar', {})
        if isQualificationBattle(avatarResults):
            self.__setQualificationData(avatarResults, reusable)
        else:
            self.__setProgressionData(avatarResults)

    def __setQualificationData(self, avatarResults, reusable):
        teamResult = reusable.getPersonalTeamResult()
        isDeserter = checkIfDeserter(reusable, FairplayViolations.COMP7_DESERTER)
        battleNumber = avatarResults.get('comp7QualBattleIndex', 0) + 1
        self.linkage = COMP7_CONSTS.COMP7_QUALIFICATION_SUB_TASK_UI
        self.title = self.__getQualificationTitle()
        self.descr = self.__getQualificationDescription(teamResult, isDeserter, battleNumber)
        self.icon = self.__getQualificationIcon(teamResult, isDeserter)

    def __setProgressionData(self, avatarResults):
        achievedRating = avatarResults.get('comp7RatingDelta', 0)
        prevRating = avatarResults.get('comp7Rating', 0)
        prevRank, prevDivisionIdx, _ = avatarResults.get('comp7Rank', (0, 0, 0))
        prevDivision = comp7_shared.getPlayerDivisionByRankAndIndex(prevRank, prevDivisionIdx)
        currentRating = max(prevRating + achievedRating, 0)
        currentDivision = comp7_shared.getPlayerDivisionByRating(currentRating)
        currentRankValue = comp7_shared.getRankEnumValue(currentDivision).value
        seasonName = comp7_core_model_helpers.getSeasonNameEnum(self.__comp7Controller, SeasonName).value
        rankName = comp7_i18n_helpers.RANK_MAP[currentRankValue]
        self.linkage = COMP7_CONSTS.COMP7_RANK_SUB_TASK_UI
        self.icon = backport.image(R.images.comp7.gui.maps.icons.ranks.dyn(seasonName).c_64.dyn(rankName)())
        self.title = self.__getTitle(currentDivision, prevDivision)
        self.descr = self.__getDescription(achievedRating, currentDivision)
        self.ratingDiff = self.__getRatingDiff(achievedRating)
        self.hasProgressBar = EXTRA_RANK_TAG not in currentDivision.tags
        self.progressBegin = currentDivision.range.begin
        self.progressCurrent = currentRating
        self.progressTotal = currentDivision.range.end + 1
        self.ratingTotal = text_styles.counter(backport.text(R.strings.comp7_ext.battleResult.subTask.rating(), rating=currentRating))

    @classmethod
    def __getDescription(cls, achievedRating, division):
        isExtraRank = EXTRA_RANK_TAG in division.tags
        isElite = comp7_shared.isElite()
        extraPropertyName = ''
        if isExtraRank:
            extraPropertyName = 'Elite' if isElite else 'Master'
        propertyName = '{}{}Rating'.format('get' if achievedRating >= 0 else 'lose', extraPropertyName if extraPropertyName else '')
        ranksConfig = cls.__comp7Controller.getRanksConfig()
        ratingText = R.strings.comp7_ext.battleResult.subTask.descr.dyn(propertyName)()
        return text_styles.main(backport.text(ratingText, topPercentage=ranksConfig.eliteRankPercent))

    @staticmethod
    def __getTitle(division, prevDivision):
        currentRankValue = comp7_shared.getRankEnumValue(division).value
        currentDivisionValue = comp7_shared.getDivisionEnumValue(division)
        if EXTRA_RANK_TAG in division.tags:
            return text_styles.middleTitle(comp7_i18n_helpers.getRankLocale(currentRankValue))
        if division.dvsnID < prevDivision.dvsnID:
            title = R.strings.comp7_ext.battleResult.subTask.title.c_raise()
        elif division.dvsnID > prevDivision.dvsnID:
            title = R.strings.comp7_ext.battleResult.subTask.title.decrease()
        else:
            title = R.strings.comp7_ext.battleResult.subTask.title.noRaise()
        return text_styles.middleTitle(backport.text(title, division=backport.text(R.strings.comp7_ext.division.text(), division=comp7_i18n_helpers.getDivisionLocale(currentDivisionValue)), rank=comp7_i18n_helpers.getRankLocale(currentRankValue)))

    @staticmethod
    def __getRatingDiff(achievedRating):
        return text_styles.error(getFormattedRating(achievedRating)) if achievedRating < 0 else text_styles.bonusAppliedText(getFormattedRating(achievedRating))

    @staticmethod
    def __getQualificationTitle():
        return text_styles.middleTitle(backport.text(R.strings.comp7_ext.battleResult.qualification.title()))

    @staticmethod
    def __getQualificationDescription(teamResult, isDeserter, battleNumber):
        if isDeserter:
            battleResult = backport.text(R.strings.comp7_ext.battleResult.label.deserter())
        else:
            battleResult = backport.text(R.strings.menu.finalStatistic.commonStats.resultlabel.dyn(teamResult)())
        mainText = backport.text(R.strings.comp7_ext.battleResult.qualification.descr.main())
        statsText = backport.text(R.strings.comp7_ext.battleResult.qualification.descr.stats(), battleNumber=battleNumber, battleResult=battleResult)
        return text_styles.concatStylesWithSpace(text_styles.main(mainText), text_styles.stats(statsText))

    @staticmethod
    def __getQualificationIcon(teamResult, isDeserter):
        if teamResult == PLAYER_TEAM_RESULT.WIN and not isDeserter:
            battleState = BattleState.VICTORY
        else:
            battleState = BattleState.DEFEAT
        return backport.image(R.images.comp7.gui.maps.icons.icons.dyn('battle_{}'.format(battleState.value))())
